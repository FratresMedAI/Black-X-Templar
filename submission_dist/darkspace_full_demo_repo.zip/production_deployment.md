# DARKSPACE Production Deployment Guide

This guide describes the hardened headless deployment profile for DARKSPACE core services.

## 1) Package boundaries

- Core package (submission target): headless modules + CLI + k8s manifests.
- Demo package (optional): `app.py` + Streamlit UI (`requirements-demo.txt`).

Install core only:

```bash
pip install -r requirements.txt
```

Install demo dashboard optionally:

```bash
pip install -r requirements-demo.txt
```

## 2) Offline-first posture

DARKSPACE defaults to offline mode unless explicitly overridden.

```bash
set DARKSPACE_OFFLINE_ONLY=true
```

Pre-seed IOC cache before disconnected operation:

```bash
python preseed_ioc_cache.py --input ioc_seed.json --clear
```

## 3) Container hardening requirements

Current image baseline in `Dockerfile`:

- non-root runtime user
- minimal Python base image

Deployment requirements (must enforce at runtime):

- read-only root filesystem
- no privilege escalation
- dropped Linux capabilities
- seccomp runtime default
- secrets mounted as files (not plaintext env vars)

## 4) Secrets handling

Do not ship real secrets in code or container image.

Recommended:

- Kubernetes secrets mounted as files
- external secret manager integration (HashiCorp Vault, cloud KMS, or enclave-approved equivalent)
- rotate `DARKSPACE_HMAC_SECRET` regularly

## 5) Observability

Current: SQLite-backed metrics + logs.

Production recommendation:

- publish security metrics to Prometheus endpoint
- ship dashboarding via Grafana in SOC environment
- retain signed event artifacts for forensic review

## 6) P2P trust requirements

For production, provision PKI-issued certs:

```bash
set DARKSPACE_P2P_TLS_CERT_PATH=/path/to/node.crt
set DARKSPACE_P2P_TLS_KEY_PATH=/path/to/node.key
set DARKSPACE_P2P_REQUIRE_MUTUAL_AUTH=true
set DARKSPACE_PEER_FINGERPRINTS=<fp1>,<fp2>
```

Self-signed behavior is dev-only and not part of production posture.

## 7) Security gates before release

- `python _smoke_v2.py`
- `python -m bandit -r . -x .venv,__pycache__ -f json -o bandit-report.json`
- `python -m pip_audit -r requirements.txt --strict`
- `semgrep --config=p/ci --error --json --output semgrep-report.json`
- generate both SBOMs (`sbom.cdx.json`, `sbom.spdx.json`)
